List of libraries used:
glob
pandas
pickle
numpy
sys
json
os
matplotlib.pyplot
tensorflow
sklearn

The file structure for testing is attached in report.


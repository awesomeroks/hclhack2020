The tool is developed in Python exclusively using libraries.

List of libraries used:
dpkt
glob
os 
socket
multiprocessing
winsound
numpy
matplotlib.pyplot 
pandas
pickle
sklearn

How to install libraries: 
The pip install command works for all python libraries. 
pip install *library name*



main file for running is ddosdetect.py

clustering.py was used for testing purposes. we noticed no big change if we clustered data or not.

PS2_DDOS.ipynb is the final file used for training.

extractor.py was used for feature extraction